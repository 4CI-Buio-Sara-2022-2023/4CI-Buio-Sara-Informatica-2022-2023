
/**
 * Aggiungi qui una descrizione della classe ActionListenerprelievo100
 * 
 * @author (il tuo nome) 
 * @version (un numero di versione o una data)
 */
import javax.swing.*;
import java.awt.event.*;
public class ActionListenerprelievo100 implements ActionListener{
    private JTextArea textArea;
    private JTextField textField;
    private Banca cont;
    
    @Override
    public void actionPerformed(ActionEvent e) {
        Conto conti = this.cont.getLastCont();
        double saldo = Double.parseDouble(textField.getText());
        saldo -= 100;
        textArea.append("prelievo di 100€ effettuato" + "\n");
    }
    public ActionListenerprelievo100(Banca c, JTextField f, JTextArea a){
        this.textArea = a;
        this.textField = f;
        this.cont = c;
    }    
}