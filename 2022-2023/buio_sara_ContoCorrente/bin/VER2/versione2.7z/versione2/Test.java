
/**
 * Aggiungi qui una descrizione della classe Test
 * 
 * @author (Buio Sara) 
 * @version (un numero di versione o una data)
 */
public class Test {
    public static void main(String[] args) {
        FinestraBanca avviare = new FinestraBanca();
        avviare.setVisible(true);
    }
}
